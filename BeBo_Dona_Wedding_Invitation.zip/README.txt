BeBo & Dona — Wedding Invitation Website

Files:
- index.html: complete responsive invitation site (HTML, CSS, and JavaScript in one file).

Included:
- Cinematic opening animation
- English / Arabic language switch
- Countdown to 19 November 2026 at 9:00 PM (Egypt time)
- Church and reception map-search links
- RSVP buttons that open WhatsApp with a prefilled reply
- Mobile-responsive styling

Before publishing:
1. Replace the sample wedding image URL in index.html with a photo of BeBo and Dona. There are two occurrences of the sample Unsplash URL (hero background and photo image); you can replace them with the same hosted image URL, or add a local image and update the paths.
2. The map links search for St. George Church and Castel Hall in Assiut. If the venue is in another city or you have exact Google Maps links, replace those href URLs.
3. RSVP currently opens WhatsApp without a fixed recipient, so guests can choose the couple's chat. To send replies directly to one number, replace `https://wa.me/?text=` with `https://wa.me/COUNTRYCODEPHONENUMBER?text=` (digits only).

Publish with GitHub Pages:
1. Create a new public repository on GitHub.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for the Pages deployment to finish and open the URL shown in Settings > Pages.
